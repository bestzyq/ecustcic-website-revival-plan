<?php
if(!defined('InSign')) exit;

define('db_host','localhost');
define('db_user','apply'); //数据库用户
define('db_pw',''); //数据库密码
define('db_name','apply_fix'); //数据表名